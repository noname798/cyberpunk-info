document.addEventListener("DOMContentLoaded", () => {
    // Observer pour les éléments visibles
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
            } else {
                entry.target.classList.remove("visible"); // Retirer la classe si l'élément n'est plus visible
            }
        });
    }, { threshold: 0.1 });

    // Observer chaque section avec la classe "hidden"
    document.querySelectorAll(".hidden").forEach(section => {
        observer.observe(section);
    });
});

// Gestion du carrousel
let currentIndex = 0;
const images = document.querySelectorAll('.slider img');
const totalImages = images.length;
const slider = document.querySelector('.slider'); // Optimisation de la sélection de l'élément slider

function showNextImage() {
    currentIndex = (currentIndex + 1) % totalImages; // Passer à l'image suivante

    // Si l'on atteint la dernière image, on fait un slide vers la première
    if (currentIndex === 0) {
        // Désactive la transition pour permettre le slide immédiat vers la première image
        slider.style.transition = "none"; 
        slider.style.transform = `translateX(-${currentIndex * 100}%)`; // Revenir à la première image (sans transition)

        // Créer l'effet de slide vers la première image après un court délai
        setTimeout(() => {
            slider.style.transition = "transform 0.5s ease-in-out"; // Réactive la transition
            slider.style.transform = `translateX(0%)`; // Slide vers la première image avec une transition fluide
        }, 50); // Petit délai pour permettre la réactivation de la transition
    } else {
        slider.style.transform = `translateX(-${currentIndex * 100}%)`; // Continue la transition normale
    }
}

// Changer d'image toutes les 5 secondes
setInterval(showNextImage, 5000);
